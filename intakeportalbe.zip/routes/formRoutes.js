const express = require("express");
const UserForm = require("../models/formScheema");
const app = express.Router();



app.post("/submitform", async (req, res) => {
  try {
    const formData = new UserForm(req.body);
    await formData.save();
    res.status(201).json({ message: "Form submitted successfully", data: formData });
  } catch (error) {
    res.status(400).json({ message: "Error submitting form", error: error.message });
  }
});




app.get("/getformdata", async (req, res) => {
  try {
    const forms = await UserForm.find();
    res.status(200).json(forms);
  } catch (error) {
    res.status(500).json({ message: "Error fetching forms", error: error.message });
  }
});
module.exports = app;